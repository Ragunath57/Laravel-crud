<!DOCTYPE html>
<html>
<head>
    <title> CRUD</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
  
<div class="container" style="margin-top: 15px;">
    <?php echo $__env->yieldContent('content'); ?>
</div>
   
</body>
</html><?php /**PATH D:\xampp\htdocs\Laravel_crud\resources\views/product/layout.blade.php ENDPATH**/ ?>