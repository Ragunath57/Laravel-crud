1) Composer Install
2) php artisan migrate
3) php artisan key:generate
4) php artisan config:cache
5) url: localhost/Laravel/product